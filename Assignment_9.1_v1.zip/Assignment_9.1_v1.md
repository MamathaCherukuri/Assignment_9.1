

```python
#Import the iris dataset
from sklearn.datasets import load_iris
```


```python
iris=load_iris()
```


```python
import pandas as pd
```


```python
import numpy as np
```


```python
data=pd.DataFrame(iris.data,columns=iris.feature_names)
```


```python
label=pd.DataFrame(list(map(lambda x: iris.target_names[x],iris.target)),
                   columns=['Species'])
```


```python
iris=pd.concat([data,label],axis=1)
```


```python
print(iris.head(20))
```

        sepal_length  sepal_width  petal_length  petal_width species
    0            5.1          3.5           1.4          0.2  setosa
    1            4.9          3.0           1.4          0.2  setosa
    2            4.7          3.2           1.3          0.2  setosa
    3            4.6          3.1           1.5          0.2  setosa
    4            5.0          3.6           1.4          0.2  setosa
    5            5.4          3.9           1.7          0.4  setosa
    6            4.6          3.4           1.4          0.3  setosa
    7            5.0          3.4           1.5          0.2  setosa
    8            4.4          2.9           1.4          0.2  setosa
    9            4.9          3.1           1.5          0.1  setosa
    10           5.4          3.7           1.5          0.2  setosa
    11           4.8          3.4           1.6          0.2  setosa
    12           4.8          3.0           1.4          0.1  setosa
    13           4.3          3.0           1.1          0.1  setosa
    14           5.8          4.0           1.2          0.2  setosa
    15           5.7          4.4           1.5          0.4  setosa
    16           5.4          3.9           1.3          0.4  setosa
    17           5.1          3.5           1.4          0.3  setosa
    18           5.7          3.8           1.7          0.3  setosa
    19           5.1          3.8           1.5          0.3  setosa
    


```python
  Use the distplot() to see the distribution of the sepallength cm,
Sepalwidth cm, PetalLength Cm features. Plot them as subplots in a single image.
    
```


```python
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
```


```python
sns.set(font_scale=1.5,palette='colorblind',style='white')
g=sns.pairplot(iris,hue='Species',size=2,aspect=1)
g.fig.suptitle('Pair plot of flower dimensions split by Species')
```

    C:\Users\User\Anaconda3\lib\site-packages\seaborn\axisgrid.py:2065: UserWarning: The `size` parameter has been renamed to `height`; pleaes update your code.
      warnings.warn(msg, UserWarning)
    C:\Users\User\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    Text(0.5,0.98,'Pair plot of flower dimensions split by Species')




![png](output_10_2.png)



```python
Do a bloxplot of all features except "Species"
```


```python
iris=sns.load_dataset("iris")
ax=sns.boxplot(data=iris,orient="h",palette="Set2")
```


![png](output_12_0.png)



```python
#Do a countplot for the feature species
iris=sns.load_dataset("iris")
sns.set(style="darkgrid")
sns.countplot(x="species",data=iris)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2b310b39a20>




![png](output_13_1.png)



```python
#Do a pairplot on the features "SepalLengthCm", "SepalWidthCm"
#,"PetalLengthCm","PetalWidthCm,"Species")
```


```python
g=sns.PairGrid(iris,hue="species",hue_kws={"cmap":["Blues","Greens","Reds"]})
g=g.map_diag(sns.kdeplot,lw=3)
g=g.map_offdiag(sns.kdeplot,lw=1)

plt.show()
```

    C:\Users\User\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    C:\Users\User\Anaconda3\lib\site-packages\matplotlib\contour.py:1004: UserWarning: The following kwargs were not used by contour: 'lw'
      s)
    


![png](output_15_1.png)



```python
#Do an lmplot on the following SepalLengthCm, PetalLengthCm. Using hue, display the 
# different species in different colors.
```


```python

sns.lmplot("sepal_length", "sepal_width", data=iris, hue="species", fit_reg=False)

```




    <seaborn.axisgrid.FacetGrid at 0x2b3136db400>




![png](output_17_1.png)



```python
iris.dtypes
```




    sepal_length    float64
    sepal_width     float64
    petal_length    float64
    petal_width     float64
    species          object
    dtype: object




```python
#Do a barplot of species vs sepallength
```


```python
sns.barplot(x="species",y="sepal_length",data=iris)
```

    C:\Users\User\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    <matplotlib.axes._subplots.AxesSubplot at 0x2b313746a58>




![png](output_20_2.png)



```python
#using heatmap, plot correlation matrix
```


```python
corr=iris.corr()
sns.heatmap(corr,linewidth=0.3,vmax=1.0,square=True,annot=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2b31145ebe0>




![png](output_22_1.png)



```python

```


```python

```


```python

```
